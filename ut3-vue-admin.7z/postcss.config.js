module.exports = {
  plugins: {
    'autoprefixer': {browsers: 'last 5 version'}
  }
}
